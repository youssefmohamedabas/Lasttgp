import requests
import json
from bs4 import BeautifulSoup


def parse_2b_page(url, category_type, page_no):
    full_url = f"{url}?p={page_no}"
    print("Fetching URL:", full_url)

    response = requests.get(full_url)

    if response.status_code == 200:
        print("Page fetched successfully")

        soup = BeautifulSoup(response.content, 'html.parser')

        product_items = soup.find_all('div', class_='product-item-info')

        products = []

        for item in product_items:
            product_name_tag = item.find('strong', class_='product name product-item-name')
            product_url_tag = item.find('a', class_='product-item-link')
            image_tag = item.find('img', class_='product-image-photo')
            price_container = item.find('span', class_='price-wrapper')

            if product_name_tag and product_url_tag and image_tag:
                product_name = product_name_tag.text.strip()
                product_url = product_url_tag['href']
                image_url = image_tag['data-src']
                product_price = None
                if price_container:
                    price_tag = price_container.find('span', class_='price')
                    if price_tag:
                        product_price = price_tag.text.strip()

                products.append({
                    "name": product_name,
                    "price": product_price,
                    "image_url": image_url,
                    "product_url": product_url,
                    "category_type": category_type
                })

        return products
    else:
        print("Failed to fetch the page. Status code:", response.status_code)
        return None


def parse_2b_pages():
    urls = [
        {"url": "https://2b.com.eg/en/home-appliances.html", "category_type": "Appliances"},
        {"url": "https://2b.com.eg/en/televisions.html", "category_type": "Appliances"},
        {"url": "https://2b.com.eg/en/electronics.html", "category_type": "Appliances"},

    ]

    all_products = []

    for url_info in urls:
        for page_no in range(1, 3):  # Limit to 2 pages
            print(f"Parsing URL {url_info['url']} page {page_no}...")
            products_on_page = parse_2b_page(url_info['url'], url_info['category_type'], page_no)

            if products_on_page:
                all_products.extend(products_on_page)

    with open("products_2b_appliances.json", "w") as json_file:
        json.dump(all_products, json_file, indent=4)

    print("Products parsed and results written to products_2b_appliances.json")


parse_2b_pages()
