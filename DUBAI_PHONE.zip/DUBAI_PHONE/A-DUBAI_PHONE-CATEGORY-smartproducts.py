import requests
import json
from bs4 import BeautifulSoup


def parse_dubaiphone_page(url, category_type):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }

    all_products = []
    page = 1

    while True:
        paginated_url = f"{url}&page={page}"
        print("Fetching URL:", paginated_url)
        response = requests.get(paginated_url, headers=headers)

        if response.status_code == 200:
            print("Page fetched successfully")
            soup = BeautifulSoup(response.content, 'html.parser')

            product_items = soup.find_all('div', class_='dp-product-item')

            if not product_items:
                break  # Break if no more products are found

            for item in product_items:
                product_name = item.find('a', class_='dp-product-title').text.strip()
                product_url = item.find('a', class_='dp-product-title')['href']
                image_url = item.find('img', class_='attachment-woocommerce_thumbnail')['src']
                price = item.find('span', class_='woocommerce-Price-amount').text.strip()
                currency = "EGP"  # Assuming the currency is always EGP
                product_price = f"{price} {currency}"

                all_products.append({
                    "name": product_name,
                    "price": product_price,
                    "image_url": image_url,
                    "product_url": product_url,
                    "category_type": category_type
                })

            page += 1
        else:
            print("Failed to fetch the page. Status code:", response.status_code)
            break

    return all_products


def parse_dubaiphone_pages():
    urls = [
        {"url": "https://www.dubaiphone.net/category/all/all-laptops/?orderby=popularity", "category_type": "smart_products"},
        {"url": "https://www.dubaiphone.net/category/all/mobiles-all/?orderby=popularity", "category_type": "smart_products"},
        {"url": "https://www.dubaiphone.net/category/all/mobile-accessories-all/?orderby=popularity",
         "category_type": "smart_products"},
    ]

    all_products = []

    for url_info in urls:
        print(f"Parsing URL {url_info['url']}...")
        products_on_page = parse_dubaiphone_page(url_info['url'], url_info['category_type'])

        if products_on_page:
            all_products.extend(products_on_page)

    with open("products_dubaiphone-smart-products.json", "w") as json_file:
        json.dump(all_products, json_file, indent=4)

    print("Products parsed and results written to products_dubaiphone-smart-products.json")


if __name__ == "__main__":
    parse_dubaiphone_pages()
