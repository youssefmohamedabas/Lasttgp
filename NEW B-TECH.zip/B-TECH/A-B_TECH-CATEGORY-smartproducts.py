import time
import json
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def fetch_products(url, category_type):
    products = []


    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--window-size=1920x1080")

    # Replace with your WebDriver path
    webdriver_path = 'E:\zz\chromedriver-win64\chromedriver.exe'
    service = ChromeService(webdriver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        driver.get(url)
        time.sleep(10)

        while True:
            soup = BeautifulSoup(driver.page_source, 'html.parser')

            product_cards = soup.find_all('div', class_='product-item-view')

            for card in product_cards:
                product_name_tag = card.find('h2', class_='plpTitle')
                product_price_tag = card.find('span', class_='price-wrapper')
                image_tag = card.find('img', class_='product-image-photo')
                product_url_tag = card.find('a', class_='listingWrapperSection')

                if product_name_tag and product_price_tag and image_tag and product_url_tag:
                    product_name = product_name_tag.text.strip()
                    product_price = product_price_tag.text.strip()


                    image_url = image_tag.get('src') or image_tag.get('data-src')

                    if image_url:
                        main_product_url = product_url_tag['href']

                        product = {
                            "name": product_name,
                            "price": product_price,
                            "image_url": image_url,
                            "product_url": main_product_url,
                            "category_type": category_type
                        }


                        if product not in products:
                            products.append(product)

            try:

                load_more_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, 'amscroll-load-button'))
                )

                if load_more_button:
                    driver.execute_script("arguments[0].click();", load_more_button)
                    time.sleep(10)  # Adjust as needed for button click and content load
                else:
                    break

            except Exception as e:
                print(f"Error while trying to find 'Show more' button: {e}")
                break

    finally:
        driver.quit()

    return products

def parse_btech_pages():
    urls = [
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=2486",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=2498",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5833",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5834",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5835",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5836",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5837",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5838",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5839",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5840",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5841",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5843",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5844",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5847",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5851",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=5878",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=6157",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=13198",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=13641",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=14453",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=15079",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=15099",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=15403",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=15563",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=17110",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=16317",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/mobile-phones-smartphones.html?category_new=15711",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=16317",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=15711",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=2524",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=2528",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5833",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5836",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5837",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5845",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5846",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5848",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5852",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=14382",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=15001",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5844",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5847",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=5851",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=15099",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=15453",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=15711",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=16317",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=17110",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=18801",
         "category_type": "smart_products"},
        {"url": "https://btech.com/en/laptop.html?category_new=31611",
         "category_type": "smart_products"},

    ]

    all_products = []

    for url_info in urls:
        print(f"Fetching products from URL: {url_info['url']}...")
        products_on_page = fetch_products(url_info['url'], url_info['category_type'])

        if products_on_page:
            all_products.extend(products_on_page)

    # Remove duplicates based on 'product_url'
    unique_products = [dict(t) for t in {tuple(d.items()) for d in all_products}]

    with open("products_btech_mobile_phones_laptops.json", "w") as json_file:
        json.dump(unique_products, json_file, indent=4)

    print("Products parsed and unique results written to products_btech_mobile_phones_laptops.json")

parse_btech_pages()
