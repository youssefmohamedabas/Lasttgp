import requests
import json
from bs4 import BeautifulSoup


def parse_btech_page(url, page_no, category_type):
    full_url = f"{url}?p={page_no}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    response = requests.get(full_url, headers=headers)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        products = []

        product_cards = soup.find_all('div', class_='product-item-view')

        for card in product_cards:
            product_name_tag = card.find('h2', class_='plpTitle')
            product_price_tag = card.find('span', class_='price-wrapper')
            image_tag = card.find('img', class_='product-image-photo')
            product_url_tag = card.find('a', class_='listingWrapperSection')

            if product_name_tag and product_price_tag and image_tag and product_url_tag:
                product_name = product_name_tag.text.strip()
                product_price = product_price_tag.text.strip()

                # Check for the correct image attribute
                image_url = image_tag.get('src') or image_tag.get('data-src')

                if image_url:
                    main_product_url = product_url_tag['href']

                    products.append({
                        "name": product_name,
                        "price": product_price,
                        "image_url": image_url,
                        "product_url": main_product_url,
                        "category_type": category_type
                    })

        return products
    else:
        print("Failed to fetch the page.")
        return None


def parse_btech_pages():
    urls = [
        {"url": "https://btech.com/en/new-gaming.html", "category_type": "Gaming"},

    ]

    all_products = []

    for url_info in urls:
        for page_no in range(1, 3):  # Limit to 2 pages
            print(f"Parsing URL {url_info['url']} page {page_no}...")
            products_on_page = parse_btech_page(url_info['url'], page_no, url_info['category_type'])

            if products_on_page:
                all_products.extend(products_on_page)

    with open("products_btech_Gaming.json", "w") as json_file:
        json.dump(all_products, json_file, indent=4)

    print("Products parsed and results written to products_btech_Gaming.json")


parse_btech_pages()
