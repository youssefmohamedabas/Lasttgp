import requests
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin

# Define static URLs for different categories on Egypt Laptop
category_urls = [
    {"url": "https://egyptlaptop.com/laptops", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/computers", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/datashow", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/modem-router", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/wifi-router-acccess-point", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/switches", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/cables-and-accessories", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/pci-cards-and-usb-adapters", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/fiber-optical", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/rack", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/network-storage", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/point-of-sale", "category_type": "smart_products"},
    {"url": "https://egyptlaptop.com/printers-scanners-ink-and-toner-plotter", "category_type": "smart_products"}
]


def parse_egypt_laptop_page(url, category_type):
    response = requests.get(url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')

        products = []

        product_items = soup.find_all('div', class_='ut2-gl__body')

        for item in product_items:
            product_name_elem = item.find('a', class_='product-title')
            product_url_elem = item.find('a', class_='product-title')
            image_url_elem = item.find('img', class_='ty-pict')
            price_elem = item.find('span', class_='ty-price-num')

            if not all([product_name_elem, product_url_elem, image_url_elem, price_elem]):
                print(f"Skipping product due to missing data in {url}")
                continue

            product_name = product_name_elem.text.strip()
            product_url = urljoin(url, product_url_elem['href'])
            image_url = image_url_elem.get('data-src', '')
            price = price_elem.text.strip()
            currency_elem = price_elem.find_next('span')

            if currency_elem:
                currency = currency_elem.text.strip()
            else:
                currency = ''

            product_price = f"{price} {currency}"

            products.append({
                "name": product_name,
                "price": product_price,
                "image_url": image_url,
                "product_url": product_url,
                "category_type": category_type
            })

        return products
    else:
        print(f"Failed to fetch the page {url}. Status code:", response.status_code)
        return None


def parse_egypt_laptop_pages():
    all_products = []

    for category_info in category_urls:
        url = category_info['url']
        category_type = category_info['category_type']

        print(f"Fetching products for category: {category_type}")

        # Fetch up to 2 pages for each category
        for page_no in range(1, 3):
            page_url = f"{url}?page={page_no}"
            print(f"Fetching page {page_no} from {page_url}...")
            products_on_page = parse_egypt_laptop_page(page_url, category_type)

            if products_on_page:
                all_products.extend(products_on_page)

    with open("egypt_laptop_products.json", "w", encoding='utf-8') as json_file:
        json.dump(all_products, json_file, ensure_ascii=False, indent=4)

    print(f"All pages parsed and results written to egypt_laptop_products-smart_products.json")


if __name__ == "__main__":
    parse_egypt_laptop_pages()
