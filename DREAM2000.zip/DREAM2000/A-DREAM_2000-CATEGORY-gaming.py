import requests
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def parse_dream2000_page(url, category_type):
    page_no = 1
    products = []

    while page_no <= 2:  # Limit to 2 pages
        full_url = f"{url}&p={page_no}"
        response = requests.get(full_url)

        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            product_items = soup.find_all('li', class_='item product product-item')

            if not product_items:
                break

            for item in product_items:
                product_name = item.find('strong', class_='product name product-item-name').text.strip()
                product_price = item.find('span', class_='price').text.strip()
                image_url = item.find('img', class_='product-image-photo')['src']
                relative_product_url = item.find('a', class_='product-item-link')['href']
                main_product_url = urljoin(full_url, relative_product_url)

                products.append({
                    "name": product_name,
                    "price": product_price,
                    "image_url": image_url,
                    "product_url": main_product_url,
                    "category_type": category_type
                })

            page_no += 1
        else:
            print(f"Failed to fetch page {page_no} for URL: {full_url}")
            break

    return products

def parse_dream2000():
    urls = [
        {"url": "https://dream2000.com/en/gaming.html?p=1&product_list_limit=100", "category_type": "Gaming"},

    ]

    all_products = []

    for url_info in urls:
        print(f"Fetching products for {url_info['category_type']}...")

        products_on_page = parse_dream2000_page(url_info['url'], url_info['category_type'])

        if products_on_page:
            all_products.extend(products_on_page)

    # Remove duplicates based on 'product_url'
    unique_products = {product['product_url']: product for product in all_products}.values()

    unique_products_list = list(unique_products)

    if unique_products_list:
        with open("dream2000_products-gaming.json", "w", encoding='utf-8') as json_file:
            json.dump(unique_products_list, json_file, indent=4, ensure_ascii=False)

        print("Products parsed and unique results written to dream2000_products-gaming.json")
    else:
        print("No products found.")

# Example usage:
parse_dream2000()
