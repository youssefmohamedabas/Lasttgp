import requests
import json
from bs4 import BeautifulSoup

def parse_jumia_page(url, page_no, category_type):
    full_url = f"{url}?page={page_no}#catalog-listing"
    response = requests.get(full_url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')

        products = []

        product_cards = soup.find_all('a', class_='core')

        for card in product_cards:
            product_name_tag = card.find('h3', class_='name')
            product_price_tag = card.find('div', class_='prc')
            image_tag = card.find('img', class_='img')
            relative_product_url = card['href']

            if product_name_tag and product_price_tag and image_tag:
                product_name = product_name_tag.text.strip()
                product_price = product_price_tag.text.strip()
                image_url = image_tag['data-src']
                main_product_url = f"https://jumia.com.eg{relative_product_url}"

                products.append({
                    "name": product_name,
                    "price": product_price,
                    "image_url": image_url,
                    "product_url": main_product_url,
                    "category_type": category_type
                })

        return products
    else:
        print("Failed to fetch the page.")
        return None


def parse_jumia_pages():
    urls = [
        {"url": "https://www.jumia.com.eg/video-games/", "category_type": "Gaming"},

    ]

    all_products = []

    for url_info in urls:
        for page_no in range(1, 3):  # Limit to 2 pages
            print(f"Parsing URL {url_info['url']} page {page_no}...")
            products_on_page = parse_jumia_page(url_info['url'], page_no, url_info['category_type'])

            if products_on_page:
                all_products.extend(products_on_page)

    with open("products_gaming.json", "w") as json_file:
        json.dump(all_products, json_file, indent=4)

    print("Products parsed and results written to products_gaming.json")


parse_jumia_pages()
