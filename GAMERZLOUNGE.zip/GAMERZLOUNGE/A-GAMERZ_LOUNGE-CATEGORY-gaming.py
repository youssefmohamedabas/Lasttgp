import requests
from bs4 import BeautifulSoup
import json
from urllib.parse import urljoin

# Function to parse a single page of products
def parse_gamerz_lounge_page(url, category_type, seen_urls):
    response = requests.get(url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        product_items = soup.find_all('div', class_='product-layout')

        products = []

        for item in product_items:
            product_name = item.find('div', class_='name').find('a').text.strip()
            product_url = item.find('div', class_='name').find('a')['href']

            # Ensure proper construction of the product URL
            main_product_url = urljoin(url, product_url)

            # Skip if product URL has been seen already to avoid duplicates
            if main_product_url in seen_urls:
                continue
            seen_urls.add(main_product_url)

            # Fetch image URL from the product page
            product_response = requests.get(main_product_url)
            if product_response.status_code == 200:
                product_soup = BeautifulSoup(product_response.content, 'html.parser')
                image_element = product_soup.find('img', class_='img-responsive')
                image_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVUUI5o1kjU8nOtlTX_JudKFGBNRAX9D-URw&s" if image_element else None
            else:
                image_url = None

            # Check if the price exists before accessing its text
            price_elem = item.find('span', class_='price-normal')
            product_price = price_elem.text.strip() if price_elem else "Price not available"
            currency = "EGP"  # Assuming the currency is EGP for Gamerz Lounge

            products.append({
                "name": product_name,
                "price": f"{product_price} {currency}",
                "image_url": image_url,
                "product_url": main_product_url,
                "category_type": category_type
            })

        return products
    else:
        print(f"Failed to fetch the page {url}. Status code:", response.status_code)
        return None

# Function to fetch and parse up to 3 pages for a given category
def parse_gamerz_lounge_category(category_url, category_type):
    base_url = "https://gamerzlounge.me"
    all_products = []
    seen_urls = set()  # Set to track seen product URLs

    for page_no in range(1, 4):  # Fetching up to 3 pages
        page_url = f"{category_url}&limit=100&page={page_no}"
        print(f"Fetching page {page_no} from {category_url}...")

        products_on_page = parse_gamerz_lounge_page(page_url, category_type, seen_urls)

        if products_on_page:
            all_products.extend(products_on_page)
        else:
            break

    return all_products

# Main function to initiate scraping for multiple categories
def main():
    categories = {
        "Gaming": "https://gamerzlounge.me/index.php?route=product/catalog"
    }

    all_products = []
    for category, url in categories.items():
        print(f"Fetching products for category: {category}")
        products = parse_gamerz_lounge_category(url, category)

        if products:
            all_products.extend(products)

    # Write all products to a single JSON file
    with open("gamerz_lounge_all_products.json", "w", encoding="utf-8") as json_file:
        json.dump(all_products, json_file, indent=4, ensure_ascii=False)

    print(f"All products parsed and written to gamerz_lounge_all_products.json")

if __name__ == "__main__":
    main()
