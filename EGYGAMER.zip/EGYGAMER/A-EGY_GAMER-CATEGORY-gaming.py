import requests
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin

# Function to parse a single page of products
def parse_egygamer_page(url, category_type, seen_urls):
    response = requests.get(url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')

        products = []

        product_cards = soup.find_all('li', class_='product-item')

        for card in product_cards:
            product_name = card.find('a', class_='product-item-link').text.strip()

            # Check if price is available
            price_element = card.find('span', class_='price')
            if price_element:
                product_price = price_element.text.strip()
            else:
                product_price = "Price not available"

            # Check if image is available
            image_element = card.find('img', class_='product-image-photo')
            if image_element and 'src' in image_element.attrs:
                image_url = image_element['src']
                if image_url.startswith('data:image/svg+xml'):
                    image_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWi-spEzTdV-cdPNQNcjrUuJB_f1zZPBWtcg&s"  # Set a default image URL
            else:
                image_url = "Image not available"

            # Check if product link is available
            link_element = card.find('a', class_='product-item-link')
            if link_element and 'href' in link_element.attrs:
                relative_product_url = link_element['href']
                # Ensure proper construction of the URL
                main_product_url = urljoin(url, relative_product_url)
                if main_product_url in seen_urls:
                    continue  # Skip duplicate products
                seen_urls.add(main_product_url)
            else:
                main_product_url = "Link not available"

            products.append({
                "name": product_name,
                "price": product_price,
                "image_url": image_url,
                "product_url": main_product_url,
                "category_type": category_type
            })

        return products
    else:
        print(f"Failed to fetch the page {url}. Status code:", response.status_code)
        return None

# Function to fetch and parse up to 3 pages for a given category
def parse_egygamer_category(category_url, category_type):
    all_products = []
    seen_urls = set()  # Set to track seen product URLs

    page_no = 1
    max_pages = 3  # Limit to 3 pages

    while page_no <= max_pages:
        page_url = f"{category_url}?product_list_limit=36&p={page_no}"
        print(f"Fetching page {page_no} from {category_url}...")

        products_on_page = parse_egygamer_page(page_url, category_type, seen_urls)

        if products_on_page:
            all_products.extend(products_on_page)
            page_no += 1
        else:
            break

    return all_products

# Main function to initiate scraping for multiple categories
def main():
    categories = {
        "Gaming": "https://www.egygamer.com/en/playstation",
        "Gaming": "https://www.egygamer.com/en/console",
        "Gaming": "https://www.egygamer.com/en/hardware",
        "Gaming": "https://www.egygamer.com/en/digital-codes",
        "Gaming": "https://www.egygamer.com/en/merchandise",
        "Gaming": "https://www.egygamer.com/en/used"
    }

    all_products = []
    seen_urls = set()  # Set to track seen product URLs across all categories

    for category, url in categories.items():
        print(f"Fetching products for category: {category}")
        products = parse_egygamer_category(url, category)

        if products:
            all_products.extend(products)

    # Write all products to a single JSON file
    with open("egygamer_all_products.json", "w", encoding="utf-8") as json_file:
        json.dump(all_products, json_file, indent=4, ensure_ascii=False)

    print(f"All products parsed and written to egygamer_all_products.json")

if __name__ == "__main__":
    main()
